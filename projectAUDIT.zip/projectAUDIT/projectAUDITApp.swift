//
//  projectAUDITApp.swift
//  projectAUDIT
//
//  Created by Arjun Mehta on 4/11/24.
//

import SwiftUI

@main
struct projectAUDITApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
